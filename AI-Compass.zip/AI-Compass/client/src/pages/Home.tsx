import { useState } from "react";
import { motion } from "framer-motion";
import { Search } from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { ToolCard } from "@/components/ui/ToolCard";
import { TipCard } from "@/components/ui/TipCard";
import { tools, tips, categories, Category } from "@/lib/data";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import heroImage from "@assets/generated_images/abstract_ai_network_visualization_with_glowing_nodes_and_connections_in_deep_blue_and_purple.png";

export default function Home() {
  const [activeCategory, setActiveCategory] = useState<Category>("All");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredTools = tools.filter((tool) => {
    const matchesCategory = activeCategory === "All" || tool.category === activeCategory;
    const matchesSearch = tool.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          tool.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const filteredTips = activeCategory === "All" 
    ? tips 
    : tips.filter(tip => tip.category === activeCategory);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      
      <main className="flex-grow pt-16">
        {/* Hero Section */}
        <section className="relative min-h-[500px] flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
            <div className="absolute inset-0 bg-background/80 z-10" />
            <div className="absolute inset-0 bg-gradient-to-b from-background via-transparent to-background z-10" />
            <img 
              src={heroImage} 
              alt="AI Background" 
              className="w-full h-full object-cover opacity-60"
            />
          </div>
          
          <div className="container relative z-20 px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl mx-auto space-y-6"
            >
              <div className="inline-block px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-4">
                The Future is Here
              </div>
              <h1 className="text-5xl md:text-7xl font-display font-bold tracking-tight text-white mb-6 drop-shadow-lg">
                Discover the best <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-purple-400">
                  AI Tools & Tips
                </span>
              </h1>
              <p className="text-xl text-muted-foreground/80 max-w-2xl mx-auto leading-relaxed">
                A curated directory of the most powerful artificial intelligence tools to supercharge your workflow, creativity, and productivity.
              </p>
              
              <div className="max-w-md mx-auto relative mt-8">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-muted-foreground" />
                </div>
                <Input
                  type="text"
                  placeholder="Search tools (e.g., 'image generation', 'coding')..."
                  className="pl-10 h-12 bg-white/5 border-white/10 text-white placeholder:text-muted-foreground/50 focus-visible:ring-primary/50 rounded-full backdrop-blur-sm transition-all focus:bg-white/10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </motion.div>
          </div>
        </section>

        <section className="container mx-auto px-4 py-16">
          <Tabs 
            defaultValue="All" 
            className="mb-12"
            onValueChange={(value) => setActiveCategory(value as Category)}
          >
            <div className="flex justify-center mb-8 overflow-x-auto pb-4 md:pb-0">
              <TabsList className="bg-white/5 p-1 rounded-full border border-white/5 backdrop-blur-sm h-auto flex-wrap justify-center">
                {categories.map((category) => (
                  <TabsTrigger
                    key={category.name}
                    value={category.name}
                    className="rounded-full px-6 py-2.5 data-[state=active]:bg-primary data-[state=active]:text-white transition-all duration-300"
                  >
                    <category.icon className="w-4 h-4 mr-2" />
                    {category.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Main Content - Tools */}
              <div className="lg:col-span-8 xl:col-span-9">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-display font-semibold flex items-center gap-2">
                    <span className="text-primary">{filteredTools.length}</span> Tools Found
                  </h2>
                </div>
                
                {filteredTools.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {filteredTools.map((tool, index) => (
                      <ToolCard key={tool.id} tool={tool} index={index} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-20 bg-white/5 rounded-2xl border border-white/5 border-dashed">
                    <p className="text-muted-foreground text-lg">No tools found matching your criteria.</p>
                    <Button variant="link" onClick={() => {setSearchQuery(""); setActiveCategory("All")}} className="mt-2 text-primary">
                      Clear filters
                    </Button>
                  </div>
                )}
              </div>

              {/* Sidebar - Tips */}
              <div className="lg:col-span-4 xl:col-span-3 space-y-6">
                <div className="sticky top-24">
                  <div className="flex items-center gap-2 mb-6">
                    <div className="h-8 w-1 bg-primary rounded-full" />
                    <h2 className="text-2xl font-display font-semibold">Pro Tips</h2>
                  </div>
                  
                  <div className="space-y-4">
                    {filteredTips.length > 0 ? (
                      filteredTips.map((tip, index) => (
                        <TipCard key={tip.id} tip={tip} index={index} />
                      ))
                    ) : (
                      <p className="text-muted-foreground italic">No specific tips for this category yet.</p>
                    )}
                    
                    <div className="p-6 mt-8 rounded-2xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-white/10 text-center">
                      <h3 className="font-semibold mb-2">Have a tip?</h3>
                      <p className="text-sm text-muted-foreground mb-4">Share your knowledge with the community.</p>
                      <Button variant="outline" className="w-full border-primary/50 hover:bg-primary/20 hover:text-white">
                        Submit Tip
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Tabs>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
