import { Bot } from "lucide-react";

export function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-white/5 bg-background/50 backdrop-blur-lg">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="bg-primary/20 p-2 rounded-lg">
            <Bot className="w-6 h-6 text-primary" />
          </div>
          <span className="font-display font-bold text-xl tracking-tight">AI Nexus</span>
        </div>
        
        <nav className="hidden md:flex items-center gap-6">
          <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Categories</a>
          <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Trending</a>
          <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Submit Tool</a>
        </nav>

        <div className="flex items-center gap-4">
          <button className="text-sm font-medium hover:text-primary transition-colors">
            Login
          </button>
        </div>
      </div>
    </header>
  );
}
