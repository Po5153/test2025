import { motion } from "framer-motion";
import { Lightbulb } from "lucide-react";
import { Tip } from "@/lib/data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface TipCardProps {
  tip: Tip;
  index: number;
}

export function TipCard({ tip, index }: TipCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3, delay: index * 0.1 }}
    >
      <Card className="bg-gradient-to-br from-primary/10 to-transparent border-primary/20 hover:border-primary/40 transition-colors">
        <CardHeader className="pb-2 flex flex-row items-center gap-3 space-y-0">
          <div className="p-2 rounded-full bg-primary/20 text-primary">
            <Lightbulb className="w-4 h-4" />
          </div>
          <CardTitle className="text-base font-medium text-primary-foreground/90">
            {tip.title}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground/80 leading-relaxed">
            {tip.content}
          </p>
          <div className="mt-3 text-xs text-primary/60 font-medium uppercase tracking-wider">
            {tip.category}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
