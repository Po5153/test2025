import { motion } from "framer-motion";
import { ExternalLink, Sparkles } from "lucide-react";
import { Tool } from "@/lib/data";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";

interface ToolCardProps {
  tool: Tool;
  index: number;
}

export function ToolCard({ tool, index }: ToolCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
    >
      <Card className="glass-card h-full flex flex-col border-white/5 hover:border-primary/30 group overflow-hidden">
        <CardHeader className="relative pb-2">
          <div className="flex justify-between items-start">
            <div className="h-12 w-12 rounded-lg bg-white/5 flex items-center justify-center text-2xl group-hover:bg-primary/20 group-hover:text-primary transition-colors duration-300">
              {tool.name.charAt(0)}
            </div>
            <div className="flex gap-2">
              {tool.isPopular && (
                <Badge variant="secondary" className="bg-amber-500/10 text-amber-500 hover:bg-amber-500/20 border-amber-500/20">
                  <Sparkles className="w-3 h-3 mr-1" />
                  Popular
                </Badge>
              )}
              {tool.isFree && (
                <Badge variant="outline" className="border-white/10 text-white/60">
                  Free
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="flex-grow">
          <h3 className="text-xl font-display font-semibold mb-2 group-hover:text-primary transition-colors">
            {tool.name}
          </h3>
          <p className="text-muted-foreground text-sm leading-relaxed">
            {tool.description}
          </p>
        </CardContent>
        <CardFooter className="pt-2">
          <Button 
            variant="ghost" 
            className="w-full justify-between hover:bg-white/5 group-hover:text-primary"
            asChild
          >
            <a href={tool.url} target="_blank" rel="noopener noreferrer">
              Visit Website
              <ExternalLink className="w-4 h-4 ml-2 opacity-50 group-hover:opacity-100 transition-opacity" />
            </a>
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}
