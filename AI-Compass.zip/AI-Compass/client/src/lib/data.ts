import { Zap, Image, Code, FileText, Music, Video, MessageSquare } from "lucide-react";

export type Category = "All" | "Text" | "Image" | "Code" | "Audio" | "Video" | "Productivity";

export interface Tool {
  id: string;
  name: string;
  description: string;
  category: Category;
  url: string;
  isFree?: boolean;
  isPopular?: boolean;
}

export interface Tip {
  id: string;
  title: string;
  content: string;
  category: Category;
}

export const tools: Tool[] = [
  {
    id: "1",
    name: "ChatGPT",
    description: "The industry standard for conversational AI, writing, and code assistance.",
    category: "Text",
    url: "#",
    isPopular: true,
    isFree: true
  },
  {
    id: "2",
    name: "Midjourney",
    description: "Generate photorealistic images and art with text prompts via Discord.",
    category: "Image",
    url: "#",
    isPopular: true
  },
  {
    id: "3",
    name: "GitHub Copilot",
    description: "Your AI pair programmer that suggests code and entire functions in real-time.",
    category: "Code",
    url: "#",
    isPopular: true
  },
  {
    id: "4",
    name: "Claude",
    description: "Anthropic's AI assistant known for handling large contexts and nuanced writing.",
    category: "Text",
    url: "#",
    isFree: true
  },
  {
    id: "5",
    name: "Notion AI",
    description: "Integrated AI assistant for summarizing, writing, and organizing your notes.",
    category: "Productivity",
    url: "#"
  },
  {
    id: "6",
    name: "Runway",
    description: "Advanced video editing and generation tools powered by generative AI.",
    category: "Video",
    url: "#"
  },
  {
    id: "7",
    name: "ElevenLabs",
    description: "The most realistic AI voice generator for creators and publishers.",
    category: "Audio",
    url: "#"
  },
  {
    id: "8",
    name: "Perplexity",
    description: "AI-powered search engine that provides cited answers to complex questions.",
    category: "Productivity",
    url: "#",
    isFree: true
  },
  {
    id: "9",
    name: "Stable Diffusion",
    description: "Open-source image generation model that you can run locally or in the cloud.",
    category: "Image",
    url: "#",
    isFree: true
  },
  {
    id: "10",
    name: "Replit Ghostwriter",
    description: "Integrated AI coding assistant directly in your browser-based IDE.",
    category: "Code",
    url: "#"
  },
  {
    id: "11",
    name: "Suno",
    description: "Generate full songs with lyrics and vocals from simple text prompts.",
    category: "Audio",
    url: "#",
    isPopular: true
  },
  {
    id: "12",
    name: "Jasper",
    description: "AI content platform built specifically for enterprise marketing teams.",
    category: "Text",
    url: "#"
  }
];

export const tips: Tip[] = [
  {
    id: "1",
    title: "Chain of Thought",
    content: "Ask the AI to 'think step-by-step' to improve reasoning on complex logic or math problems.",
    category: "Text"
  },
  {
    id: "2",
    title: "Role Prompting",
    content: "Assign a persona (e.g., 'Act as a Senior React Engineer') to get more specific and expert responses.",
    category: "Text"
  },
  {
    id: "3",
    title: "Negative Prompts",
    content: "In image generation, specify what you don't want (e.g., 'no blur, no text') to clean up results.",
    category: "Image"
  },
  {
    id: "4",
    title: "Context Windows",
    content: "If an AI forgets earlier details, summarize the conversation so far in a new prompt to refresh its context.",
    category: "Productivity"
  }
];

export const categories: { name: Category; icon: any }[] = [
  { name: "All", icon: Zap },
  { name: "Text", icon: FileText },
  { name: "Image", icon: Image },
  { name: "Code", icon: Code },
  { name: "Audio", icon: Music },
  { name: "Video", icon: Video },
  { name: "Productivity", icon: MessageSquare },
];
